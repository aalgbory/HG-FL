# HG-FL

Code and results of the article *Honest-Preserving Guarded Federated Learning for Intrusion Detection under
Non-IID IoT Traffic*.

HG-FL is a server-side aggregation framework for federated intrusion detection. In every round, the server
rejects boosted updates with a two-strike norm guard, scores every remaining client by its leave-one-out utility
on a small labelled seed set, keeps a reputation memory, averages the accepted clients with equal weights and
fine-tunes the aggregated model on the class-balanced seed set.

The code uses NumPy and scikit-learn only and runs on a CPU.

## Installation

```
python -m venv venv
venv\Scripts\activate            (Linux: source venv/bin/activate)
pip install -r requirements.txt
```

## Datasets

| Dataset | File used | Source |
| --- | --- | --- |
| CICIoT2023 | folder of CSV files | https://www.unb.ca/cic/datasets/iotdataset-2023.html |
| TON_IoT | `Train_Test_Network.csv` (network data) | https://research.unsw.edu.au/projects/toniot-datasets |
| Edge-IIoTset | `ML-EdgeIIoT-dataset.csv` | https://ieee-dataport.org/documents/edge-iiotset-new-comprehensive-realistic-cyber-security-dataset-iot-and-iiot-applications |

## Reproducing the results

Every grid of `run_experiments.py` corresponds to a part of the article:

| Grid | Article | Split |
| --- | --- | --- |
| `tuning` | Table 3 | validation (`--val`) |
| `guard` | Table 4 | validation (`--val`) |
| `main` | Tables 5-8 and 12, Figures 2-5 | test |
| `prox` | Figure 6 | test |
| `ablation` | Table 9 | test |
| `ablation_v1` | Sub-section 5.7 | test |
| `iid` | Table 10 | test |
| `skew` | Table 11 | test |

Example for one dataset and one grid:

```
python run_experiments.py --dataset ciciot2023 --data path/to/CICIoT2023 --grid main --out results/main_cic.jsonl
python run_experiments.py --dataset ciciot2023 --data path/to/CICIoT2023 --grid tuning --val --out results/tuning_cic.jsonl
python run_central.py --dataset ciciot2023 --data path/to/CICIoT2023 --out results/central_cic.jsonl
```

The dataset names are `ciciot2023`, `ton_iot` and `edge_iiotset`, and the result files are named
`<grid>_<cic|ton|edge>.jsonl`. `run_all.bat` runs every grid on the three datasets. A run that is already in the
output file is skipped, so an interrupted grid can be restarted. A grid can be shared between parallel processes
with `--worker i --workers n`.

The tables (CSV files in `results/tables`) and the figures (`figures`, PNG and MATLAB scripts) are produced from
the result files with:

```
cd analysis
python make_tables.py
python make_figures.py
```

The `results` folder contains the result files of the article, so the two scripts can be run without repeating
the experiments.

## Files

| File | Content |
| --- | --- |
| `hgfl/hgfl.py` | HG-FL aggregation (norm guard, leave-one-out utility, reputation) and the switches of the first design |
| `hgfl/simulate.py` | federated loop, server fine-tuning, method names and metrics |
| `hgfl/aggregators.py` | Krum, Multi-Krum, median, trimmed mean, DBSCAN filtering, bucketing, FLAME, FLTrust, Zeno |
| `hgfl/clients.py` | local training (FedAvg, FedProx, SCAFFOLD) and the attacks |
| `hgfl/data.py` | loading, preprocessing and Dirichlet partition |
| `hgfl/model.py` | multilayer perceptron |
| `run_experiments.py` | experiment grids |
| `run_central.py` | centralised reference (Table 10) |
| `analysis/` | tables, statistical tests and figures |

## Settings

20 clients, 40 rounds, one local epoch (SGD, learning rate 0.05, momentum 0.9, batch 64), MLP with two hidden
layers (128 and 64), Dirichlet α = 0.1, 20 seed samples per class, norm guard ρ = 2, harm threshold τ = 1.0,
reputation factor γ = 0.7, five seeds.
