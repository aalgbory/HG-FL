"""Loading of the result files and the per-run measures used in the tables and figures."""
import glob
import os

import numpy as np
import pandas as pd

ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'results')
ATT3 = ['label_flip', 'scaling', 'adaptive']
DSN = {'ciciot2023': 'CICIoT2023', 'ton_iot': 'TON_IoT', 'edge_iiotset': 'Edge-IIoTset'}
DS = list(DSN)
PUB = ['fedavg', 'fedprox', 'scaffold', 'krum', 'mkrum', 'median', 'trmean', 'dbscan', 'bucketing', 'flame',
       'fltrust', 'zeno']
NAME = dict(fedavg='FedAvg', fedprox='FedProx', scaffold='SCAFFOLD', krum='Krum', mkrum='Multi-Krum',
            median='Median', trmean='Trimmed mean', dbscan='DBSCAN filtering', bucketing='Bucketing', flame='FLAME',
            fltrust='FLTrust', zeno='Zeno', fedavg_ft='FedAvg + FT', mkrum_ft='Multi-Krum + FT', hgfl='HG-FL')


def honest_share(r, honest=True, rare_only=False):
    ex = r['client_excluded']
    if not isinstance(ex, list):
        return np.nan
    mal = set(r['malicious_clients'])
    cc = np.array(r['client_counts'])
    rc = r['rare_classes']
    tot = cc[:, rc].sum() if rc else 0
    ks = [k for k in range(len(ex)) if (k not in mal) == honest and r['client_participation'][k]]
    if rare_only:
        ks = [k for k in ks if tot and cc[k, rc].sum() / tot >= 0.1]
    return np.mean([ex[k] / r['client_participation'][k] for k in ks]) if ks else np.nan


def load(grid):
    files = sorted(glob.glob(os.path.join(ROOT, f'{grid}_*.jsonl')))
    d = pd.concat([pd.read_json(f, lines=True) for f in files], ignore_index=True)
    if 'mal_frac' in d:
        d['mal_frac'] = d.mal_frac.round(1)
    if 'rare_classes' in d:
        d['rare'] = [np.mean([r[c] for c in rc]) if isinstance(rc, list) and rc else np.nan
                     for r, rc in zip(d.per_class_recall, d.rare_classes)]
        d['hex'] = d.apply(lambda r: honest_share(r, True), axis=1)
        d['hex_rare'] = d.apply(lambda r: honest_share(r, True, True), axis=1)
        d['mex'] = d.apply(lambda r: honest_share(r, False), axis=1)
    return d


def wilcoxon_holm(W, baselines):
    """One-sided Wilcoxon signed-rank test of HG-FL against each baseline over the settings, Holm-corrected."""
    from scipy.stats import wilcoxon
    rows = []
    for b in baselines:
        diff = W['hgfl'] - W[b]
        rows.append([b, diff.mean(), int((diff > 0).sum()), wilcoxon(W['hgfl'], W[b], alternative='greater').pvalue])
    st = pd.DataFrame(rows, columns=['m', 'diff', 'wins', 'p']).sort_values('p').reset_index(drop=True)
    k = len(st)
    st['holm'] = np.maximum.accumulate([min(1, p * (k - i)) for i, p in enumerate(st.p)])
    return st
