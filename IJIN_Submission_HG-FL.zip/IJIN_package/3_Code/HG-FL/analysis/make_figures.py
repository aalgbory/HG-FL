"""Figures 2-4 of the article (PNG at 300 dpi and a MATLAB script with the data of each figure)."""
import os

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from common import ATT3, NAME, PUB, ROOT, load, wilcoxon_holm

OUT = os.path.join(ROOT, '..', 'figures')
os.makedirs(OUT, exist_ok=True)
MC = [(0, .4470, .7410), (.8500, .3250, .0980), (.9290, .6940, .1250), (.4940, .1840, .5560),
      (.4660, .6740, .1880), (.3010, .7450, .9330), (.6350, .0780, .1840)]
plt.rcParams.update({
    'font.family': 'Liberation Sans', 'font.size': 10, 'axes.linewidth': 0.6,
    'axes.edgecolor': (.15, .15, .15), 'axes.grid': True, 'grid.color': (.15, .15, .15),
    'grid.alpha': 0.15, 'grid.linewidth': 0.5, 'xtick.direction': 'in', 'ytick.direction': 'in',
    'xtick.top': True, 'ytick.right': True, 'axes.prop_cycle': matplotlib.cycler(color=MC),
    'legend.edgecolor': (.15, .15, .15), 'legend.fancybox': False, 'legend.framealpha': 1,
    'savefig.dpi': 300, 'figure.facecolor': 'white'})
MHEAD = "set(groot,'defaultAxesFontName','Arial','defaultAxesFontSize',10);\n"


def mmat(A):
    return '[' + '; '.join(' '.join(f'{x:.2f}' for x in r) for r in np.atleast_2d(A)) + ']'


def mcell(names):
    return '{' + ', '.join("'" + s + "'" for s in names) + '}'


def save(fig, name, mcode):
    fig.savefig(os.path.join(OUT, name + '.png'), bbox_inches='tight')
    plt.close(fig)
    with open(os.path.join(OUT, name + '.m'), 'w') as fh:
        fh.write(MHEAD + mcode)


D = load('main')
ATT = D[D.attack.isin(ATT3)]
per = 100 * ATT.groupby(['method', 'dataset', 'attack', 'mal_frac']).macro_f1.mean()
T = pd.DataFrame({'mean': per.groupby('method').mean(), 'worst': per.groupby('method').min(),
                  'hex': 100 * ATT.groupby('method').hex.mean(),
                  'rare_ton': 100 * ATT[ATT.dataset == 'ton_iot'].groupby('method').rare.mean(),
                  'rare_edge': 100 * ATT[ATT.dataset == 'edge_iiotset'].groupby('method').rare.mean()})

order = T.loc[PUB + ['hgfl']].sort_values('mean', ascending=False).index.tolist()
fig, ax = plt.subplots(figsize=(7.6, 4.2))
x = np.arange(len(order))
w = 0.38
ax.bar(x - w / 2, T.loc[order, 'mean'], w, color=MC[0], edgecolor='k', lw=0.4, label='Mean over the 18 settings')
ax.bar(x + w / 2, T.loc[order, 'worst'], w, color=MC[1], edgecolor='k', lw=0.4, label='Worst setting')
for xx, m in zip(x, order):
    ax.text(xx - w / 2, T.loc[m, 'mean'] + 1, f"{T.loc[m, 'mean']:.1f}", ha='center', va='bottom', fontsize=7,
            rotation=90)
    ax.text(xx + w / 2, T.loc[m, 'worst'] + 1, f"{T.loc[m, 'worst']:.1f}", ha='center', va='bottom', fontsize=7,
            rotation=90)
ax.set_xticks(x)
ax.set_xticklabels([NAME[m] for m in order], rotation=35, ha='right')
for t in ax.get_xticklabels():
    if t.get_text() == 'HG-FL':
        t.set_fontweight('bold')
ax.set_ylim(0, 80)
ax.set_ylabel('Macro-F1 (%)')
ax.legend(loc='upper right', fontsize=8)
ax.set_axisbelow(True)
fig.tight_layout()
save(fig, 'Fig2_mean_worst', "methods = " + mcell([NAME[m] for m in order]) +
     f";\nY = {mmat(T.loc[order, ['mean', 'worst']].values)};\nfigure('Position',[100 100 760 420]);\n"
     "bar(Y,'grouped'); grid on; box on; set(gca,'XTick',1:numel(methods),'XTickLabel',methods,'XTickLabelRotation',35);\n"
     "ylim([0 80]); ylabel('Macro-F1 (%)'); legend({'Mean over the 18 settings','Worst setting'},'Location','northeast');\n")

rows = []
for _, r in ATT.iterrows():
    ex = r.client_excluded
    if not isinstance(ex, list) or not r.rare_classes:
        continue
    mal = set(r.malicious_clients)
    cc = np.array(r.client_counts)
    rc = r.rare_classes
    tot = cc[:, rc].sum()
    for k in range(len(ex)):
        if k not in mal and r.client_participation[k]:
            rows.append((r.method, cc[k, rc].sum() / tot, ex[k] / r.client_participation[k]))
E = pd.DataFrame(rows, columns=['m', 'share', 'ex'])
BINS = [-1e-9, 1e-9, 0.05, 0.15, 1.0]
BL = ['none', '0-5%', '5-15%', '>15%']
E['bin'] = pd.cut(E.share, BINS, labels=BL)
EX = 100 * E.groupby(['m', 'bin'], observed=True).ex.mean().unstack()
FM = ['dbscan', 'flame', 'fltrust', 'mkrum', 'zeno', 'hgfl']
mk = ['s', 'd', '^', 'v', 'o', 'p']
fig, ax = plt.subplots(figsize=(6.4, 3.8))
for i, m in enumerate(FM):
    ax.plot(range(4), EX.loc[m, BL], marker=mk[i], ms=6, lw=2.2 if m == 'hgfl' else 1.4,
            color=MC[i], label=NAME[m], mec='k', mew=0.4)
ax.set_xticks(range(4))
ax.set_xticklabels(BL)
ax.set_xlabel("Share of the rare-class training samples held by the honest client")
ax.set_ylabel('Honest client excluded (% of rounds)')
ax.set_ylim(-2, 56)
ax.legend(ncol=3, loc='upper center', fontsize=8, bbox_to_anchor=(0.5, 1.0))
ax.set_axisbelow(True)
fig.tight_layout()
save(fig, 'Fig4_exclusion_rare_share', "bins = " + mcell(BL) + ";\nmethods = " + mcell([NAME[m] for m in FM]) +
     f";\nY = {mmat(EX.loc[FM, BL].values.T)};\nfigure('Position',[100 100 640 380]);\n"
     "plot(1:4, Y, '-o', 'LineWidth', 1.4); grid on; box on; set(gca,'XTick',1:4,'XTickLabel',bins);\n"
     "ylim([-2 56]); xlabel('Share of the rare-class training samples held by the honest client');\n"
     "ylabel('Honest client excluded (% of rounds)'); legend(methods,'Location','north','NumColumns',3);\n")

FM4 = ['dbscan', 'flame', 'fltrust', 'mkrum', 'zeno', 'mkrum_ft', 'hgfl']
X4 = T.loc[FM4, 'hex'].values
Y4 = ((T.loc[FM4, 'rare_ton'] + T.loc[FM4, 'rare_edge']) / 2).values
fig, ax = plt.subplots(figsize=(6.0, 4.0))
for i, m in enumerate(FM4):
    ax.scatter(X4[i], Y4[i], s=90 if m == 'hgfl' else 55, color=MC[i % 7], edgecolor='k', lw=0.5, zorder=3,
               marker='p' if m == 'hgfl' else 'o')
    dx, dy = (1.0, 1.5)
    if m == 'mkrum_ft':
        dx, dy = (1.0, -4.5)
    ax.annotate(NAME[m], (X4[i], Y4[i]), xytext=(X4[i] + dx, Y4[i] + dy), fontsize=8.5,
                fontweight='bold' if m == 'hgfl' else 'normal')
ax.set_xlabel('Honest clients excluded (% of client rounds)')
ax.set_ylabel('Recall of the rare attack classes (%)')
ax.set_xlim(-2, 45)
ax.set_ylim(0, 100)
ax.set_axisbelow(True)
fig.tight_layout()
save(fig, 'Fig5_exclusion_vs_rare_recall', "methods = " + mcell([NAME[m] for m in FM4]) +
     f";\nX = {mmat(X4)};\nY = {mmat(Y4)};\nfigure('Position',[100 100 600 400]);\n"
     "scatter(X, Y, 60, 'filled'); grid on; box on; text(X+1, Y+1.5, methods);\n"
     "xlim([-2 45]); ylim([0 100]); xlabel('Honest clients excluded (% of client rounds)');\n"
     "ylabel('Recall of the rare attack classes (%)');\n")

st = wilcoxon_holm(per.unstack('method'), PUB).sort_values('diff')
fig, ax = plt.subplots(figsize=(7.6, 4.4))
x = np.arange(len(st))
ax.bar(x, st['diff'], 0.62, color=MC[0], edgecolor='k', lw=0.4)


def pfmt(p):
    if p < 1e-3:
        m, e = f'{p:.1e}'.split('e')
        return f'p = {m}$\\times$10$^{{{int(e)}}}$'
    return f'p = {p:.3f}'


for xx, (_, r) in zip(x, st.iterrows()):
    ax.text(xx, r['diff'] + 1.0, f"{r['diff']:+.1f}  ({int(r['wins'])}/18, {pfmt(r['holm'])})", ha='center',
            va='bottom', fontsize=7, rotation=90)
ax.set_xticks(x)
ax.set_xticklabels([NAME[m] for m in st.m], rotation=35, ha='right')
ax.set_ylim(0, 100)
ax.set_ylabel('Mean gain of HG-FL in macro-F1 (points)')
ax.set_axisbelow(True)
fig.tight_layout()
save(fig, 'Fig3_gain_wilcoxon', "methods = " + mcell([NAME[m] for m in st.m]) +
     f";\nG = {mmat(st['diff'].values)};\nP = {mmat(st['holm'].values)};\nwins = {mmat(st['wins'].values)};\n"
     "figure('Position',[100 100 760 440]); bar(G); grid on; box on;\n"
     "set(gca,'XTick',1:numel(methods),'XTickLabel',methods,'XTickLabelRotation',35); ylim([0 100]);\n"
     "ylabel('Mean gain of HG-FL in macro-F1 (points)');\n"
     "for k = 1:numel(G), text(k, G(k)+1, sprintf('%+.1f  (%d/18, p = %.1e)', G(k), wins(k), P(k)), 'Rotation', 90, 'FontSize', 7); end\n")

PR = load('prox')
pp = 100 * PR[PR.attack.isin(ATT3)].groupby(['method', 'dataset']).macro_f1.mean()
pb = 100 * ATT.groupby(['method', 'dataset']).macro_f1.mean()
PM = ['fltrust', 'mkrum', 'median', 'trmean', 'fedavg_ft']
PL = ['FLTrust', 'Multi-Krum', 'Median', 'Trimmed\nmean', 'FedAvg\n+ FT']
DSK = [('cic', 'ciciot2023', 'CICIoT2023'), ('ton', 'ton_iot', 'TON_IoT'), ('edge', 'edge_iiotset', 'Edge-IIoTset')]
fig, axs = plt.subplots(1, 3, figsize=(10.5, 3.5), sharey=True)
mc_lines = []
for ax, (k, ds, title) in zip(axs, DSK):
    x = np.arange(len(PM))
    a0 = np.array([pb[(m, ds)] for m in PM])
    a1 = np.array([pp[(m + '+prox', ds)] for m in PM])
    ax.bar(x - 0.19, a0, 0.38, color=MC[0], edgecolor='k', lw=0.4, label='Without proximal term')
    ax.bar(x + 0.19, a1, 0.38, color=MC[2], edgecolor='k', lw=0.4, label='With proximal term')
    hv = pb[('hgfl', ds)]
    ax.axhline(hv, color=MC[6], lw=1.8, ls='--', label='HG-FL')
    ax.text(len(PM) - 0.5, hv + 1.2, f'HG-FL {hv:.1f}', ha='right', fontsize=8, color=MC[6])
    ax.set_xticks(x)
    ax.set_xticklabels(PL, fontsize=8)
    ax.set_title(title, fontsize=10)
    ax.set_ylim(0, 75)
    ax.set_axisbelow(True)
    mc_lines.append(f"Y{k} = {mmat(np.vstack([a0, a1]).T)}; H{k} = {hv:.2f};")
axs[0].set_ylabel('Mean macro-F1 under attack (%)')
h_, l_ = axs[0].get_legend_handles_labels()
fig.legend(h_, l_, loc='lower center', ncol=3, fontsize=8.5, bbox_to_anchor=(0.5, -0.02))
fig.tight_layout(rect=(0, 0.07, 1, 1))
save(fig, 'Fig6_fedprox', "methods = " + mcell([s.replace('\n', ' ') for s in PL]) + ";\n" + "\n".join(mc_lines) +
     "\nnames = {'CICIoT2023','TON_IoT','Edge-IIoTset'}; Ys = {Ycic, Yton, Yedge}; Hs = [Hcic Hton Hedge];\n"
     "figure('Position',[100 100 1050 350]);\n"
     "for i = 1:3, subplot(1,3,i); bar(Ys{i},'grouped'); hold on; yline(Hs(i),'--r','HG-FL'); grid on; box on;\n"
     "  set(gca,'XTick',1:numel(methods),'XTickLabel',methods); ylim([0 75]); title(names{i}); end\n"
     "subplot(1,3,1); ylabel('Mean macro-F1 under attack (%)');\n"
     "legend({'Without proximal term','With proximal term'},'Location','southoutside','Orientation','horizontal');\n")
