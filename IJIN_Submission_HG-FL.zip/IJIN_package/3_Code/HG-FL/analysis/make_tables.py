"""Writes the tables of the article (CSV files in results/tables) and the statistical tests."""
import os

import numpy as np
import pandas as pd
from scipy.stats import friedmanchisquare

from common import ATT3, DS, DSN, NAME, PUB, ROOT, load, wilcoxon_holm

OUT = os.path.join(ROOT, 'tables')
os.makedirs(OUT, exist_ok=True)


def save(df, name):
    df.round(2).to_csv(os.path.join(OUT, name + '.csv'))
    print(f'\n{name}\n{df.round(1).to_string()}')


def attacked(d, by):
    a = d[d.attack.isin(ATT3)]
    return 100 * a.groupby(by).macro_f1.mean()


def selection(d, keys, backdoor=False):
    per = attacked(d, ['method', 'dataset', 'attack'])
    t = pd.DataFrame({'mean': per.groupby('method').mean(), 'worst': per.groupby('method').min(),
                      'none': 100 * d[d.attack == 'none'].groupby('method').macro_f1.mean()})
    a = d[d.attack.isin(ATT3)]
    if backdoor:
        t['asr'] = 100 * d[d.attack == 'backdoor'].groupby('method').asr.mean()
        t['honest_excl_none'] = 100 * d[d.attack == 'none'].groupby('method').hex.mean()
        t['honest_excl_attack'] = 100 * d[d.attack != 'none'].groupby('method').hex.mean()
    else:
        t['rare_ton'] = 100 * a[a.dataset == 'ton_iot'].groupby('method').rare.mean()
        t['rare_edge'] = 100 * a[a.dataset == 'edge_iiotset'].groupby('method').rare.mean()
    return t.loc[keys]


tun = load('tuning')
save(selection(tun, list(dict.fromkeys(tun.method))), 'table3_tuning')
gu = load('guard')
save(selection(gu, list(dict.fromkeys(gu.method)), backdoor=True), 'table4_guard')

d = load('main')
per = attacked(d, ['method', 'dataset', 'attack', 'mal_frac'])
none = 100 * d[d.attack == 'none'].groupby(['method', 'dataset']).macro_f1.mean()
cols = [(a, f) for f in (0.3, 0.4) for a in ATT3]
for i, ds in enumerate(DS):
    t = pd.DataFrame({'none': none.xs(ds, level='dataset')})
    for a, f in cols:
        t[f'{a}_{int(f * 100)}'] = per.xs((ds, a, f), level=('dataset', 'attack', 'mal_frac'))
    save(t.loc[PUB + ['hgfl']], f'table{5 + i}_{ds}')

W = per.unstack('method')
fr = friedmanchisquare(*[W[c] for c in PUB + ['hgfl']])
st = wilcoxon_holm(W, PUB)
st['m'] = st.m.map(NAME)
print(f'\nFriedman chi2 = {fr.statistic:.1f}, p = {fr.pvalue:.2e}')
st.rename(columns={'m': 'baseline', 'diff': 'mean_gain', 'wins': 'settings_won', 'holm': 'p_holm'}).to_csv(
    os.path.join(OUT, 'figure3_wilcoxon.csv'), index=False)
print(st.to_string())

a = d[d.attack.isin(ATT3)]
summ = pd.DataFrame({'mean': per.groupby('method').mean(), 'worst': per.groupby('method').min(),
                     'sd_over_seeds': 100 * a.groupby(['method', 'dataset', 'attack', 'mal_frac']).macro_f1.std()
                     .groupby('method').mean(),
                     'rare_ton': 100 * a[a.dataset == 'ton_iot'].groupby('method').rare.mean(),
                     'rare_edge': 100 * a[a.dataset == 'edge_iiotset'].groupby('method').rare.mean(),
                     'honest_excluded': 100 * a.groupby('method').hex.mean(),
                     'rare_holders_excluded': 100 * a.groupby('method').hex_rare.mean(),
                     'malicious_excluded': 100 * a.groupby('method').mex.mean()})
save(summ.sort_values('mean', ascending=False), 'figure2_summary_18_settings')

ab = load('ablation')
f4 = d[(d.method == 'hgfl') & (d.mal_frac == 0.4)]
a4 = pd.concat([d[(d.mal_frac == 0.4) & d.method.isin(['fedavg', 'fedavg_ft', 'mkrum', 'mkrum_ft'])],
                ab[ab.method == 'hgfl_noft'], f4])
a4 = a4[a4.attack.isin(ATT3)]
p4 = 100 * a4.groupby(['method', 'dataset', 'attack']).macro_f1.mean()
save(pd.DataFrame({'mean': p4.groupby('method').mean(), 'worst': p4.groupby('method').min(),
                   'rare_ton': 100 * a4[a4.dataset == 'ton_iot'].groupby('method').rare.mean(),
                   'rare_edge': 100 * a4[a4.dataset == 'edge_iiotset'].groupby('method').rare.mean(),
                   'honest_excluded': 100 * a4.groupby('method').hex.mean()})
     .loc[['fedavg', 'fedavg_ft', 'mkrum', 'mkrum_ft', 'hgfl_noft', 'hgfl']], 'table8_fine_tuning')

pr = load('prox')
pp = attacked(pr, ['method', 'dataset'])
base = attacked(d, ['method', 'dataset'])
t = pd.DataFrame({ds: base.xs(ds, level='dataset') for ds in DS})
tp = pd.DataFrame({ds + '+prox': pp.xs(ds, level='dataset') for ds in DS})
tp.index = [m.replace('+prox', '') for m in tp.index]
save(t.join(tp, how='inner'), 'figure6_fedprox')

abl = pd.concat([ab, f4[f4.attack.isin(ATT3 + ['backdoor'])]])
aa = abl[abl.attack.isin(ATT3)]
pa = 100 * aa.groupby(['method', 'dataset', 'attack']).macro_f1.mean()
save(pd.DataFrame({'mean': pa.groupby('method').mean(), 'worst': pa.groupby('method').min(),
                   'rare_ton': 100 * aa[aa.dataset == 'ton_iot'].groupby('method').rare.mean(),
                   'honest_excluded': 100 * aa.groupby('method').hex.mean(),
                   'malicious_excluded': 100 * aa.groupby('method').mex.mean(),
                   'asr': 100 * abl[abl.attack == 'backdoor'].groupby('method').asr.mean()})
     .loc[['hgfl', 'hgfl_noft', 'hgfl_noguard', 'hgfl_norep']], 'table9_ablation')

v1 = load('ablation_v1')
pv = attacked(v1, ['method', 'dataset', 'attack'])
save(pd.DataFrame({'mean': pv.groupby('method').mean(), 'worst': pv.groupby('method').min()}), 'ablation_first_design')

c = load('central')
iid = load('iid')
save(pd.DataFrame({'centralised': 100 * c.groupby('dataset').macro_f1.mean(),
                   'fedavg_iid': 100 * iid[iid.method == 'fedavg'].groupby('dataset').macro_f1.mean(),
                   'hgfl_iid': 100 * iid[iid.method == 'hgfl'].groupby('dataset').macro_f1.mean(),
                   'fedavg_alpha0.1': none.xs('fedavg', level='method'),
                   'hgfl_alpha0.1': none.xs('hgfl', level='method')}).loc[DS], 'table10_reference')

sk = load('skew')
ps = 100 * sk.groupby(['alpha', 'method', 'dataset', 'attack']).macro_f1.mean()
save(pd.DataFrame({'mean': ps.groupby(['alpha', 'method']).mean(), 'worst': ps.groupby(['alpha', 'method']).min()})
     .unstack('alpha'), 'table11_weaker_skew')

bd = d[d.attack == 'backdoor']
t14 = pd.DataFrame({f'asr_{DSN[ds]}': 100 * bd[bd.dataset == ds].groupby('method').asr.mean() for ds in DS})
t14['far_attack'] = 100 * a.groupby('method').far.mean()
t14['far_none'] = 100 * d[d.attack == 'none'].groupby('method').far.mean()
t14['server_ms_per_round'] = 1000 * d.groupby('method').server_time_s.mean() / 40
save(t14.loc[['fltrust', 'zeno', 'flame', 'mkrum', 'krum', 'mkrum_ft', 'hgfl']], 'table12_backdoor_far_time')
