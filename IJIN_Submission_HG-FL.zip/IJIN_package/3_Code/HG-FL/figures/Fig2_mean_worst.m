set(groot,'defaultAxesFontName','Arial','defaultAxesFontSize',10);
methods = {'HG-FL', 'Zeno', 'FLTrust', 'FLAME', 'Multi-Krum', 'Median', 'Trimmed mean', 'FedProx', 'Krum', 'FedAvg', 'Bucketing', 'SCAFFOLD', 'DBSCAN filtering'};
Y = [63.77 59.08; 61.63 55.03; 57.88 52.30; 51.33 36.87; 50.13 7.72; 43.50 11.78; 34.41 5.63; 29.10 3.78; 27.95 1.54; 23.77 1.83; 22.65 4.59; 18.89 2.18; 12.31 1.40];
figure('Position',[100 100 760 420]);
bar(Y,'grouped'); grid on; box on; set(gca,'XTick',1:numel(methods),'XTickLabel',methods,'XTickLabelRotation',35);
ylim([0 80]); ylabel('Macro-F1 (%)'); legend({'Mean over the 18 settings','Worst setting'},'Location','northeast');
