set(groot,'defaultAxesFontName','Arial','defaultAxesFontSize',10);
methods = {'Zeno', 'FLTrust', 'FLAME', 'Multi-Krum', 'Median', 'Trimmed mean', 'FedProx', 'Krum', 'FedAvg', 'Bucketing', 'SCAFFOLD', 'DBSCAN filtering'};
G = [2.14 5.89 12.44 13.64 20.27 29.37 34.67 35.83 40.01 41.13 44.88 51.47];
P = [0.01 0.00 0.00 0.00 0.00 0.00 0.00 0.00 0.00 0.00 0.00 0.00];
wins = [13.00 18.00 18.00 18.00 18.00 18.00 18.00 18.00 18.00 18.00 18.00 18.00];
figure('Position',[100 100 760 440]); bar(G); grid on; box on;
set(gca,'XTick',1:numel(methods),'XTickLabel',methods,'XTickLabelRotation',35); ylim([0 100]);
ylabel('Mean gain of HG-FL in macro-F1 (points)');
for k = 1:numel(G), text(k, G(k)+1, sprintf('%+.1f  (%d/18, p = %.1e)', G(k), wins(k), P(k)), 'Rotation', 90, 'FontSize', 7); end
