set(groot,'defaultAxesFontName','Arial','defaultAxesFontSize',10);
bins = {'none', '0-5%', '5-15%', '>15%'};
methods = {'DBSCAN filtering', 'FLAME', 'FLTrust', 'Multi-Krum', 'Zeno', 'HG-FL'};
Y = [37.73 31.69 28.69 20.02 8.64 0.00; 37.38 26.56 26.07 14.32 7.06 0.00; 36.22 21.85 25.45 11.28 2.68 0.00; 39.40 27.73 18.87 16.67 5.10 0.00];
figure('Position',[100 100 640 380]);
plot(1:4, Y, '-o', 'LineWidth', 1.4); grid on; box on; set(gca,'XTick',1:4,'XTickLabel',bins);
ylim([-2 56]); xlabel('Share of the rare-class training samples held by the honest client');
ylabel('Honest client excluded (% of rounds)'); legend(methods,'Location','north','NumColumns',3);
