set(groot,'defaultAxesFontName','Arial','defaultAxesFontSize',10);
methods = {'DBSCAN filtering', 'FLAME', 'FLTrust', 'Multi-Krum', 'Zeno', 'Multi-Krum + FT', 'HG-FL'};
X = [36.71 30.90 23.49 19.15 7.85 8.65 0.01];
Y = [8.97 43.28 50.29 40.08 52.59 85.48 86.61];
figure('Position',[100 100 600 400]);
scatter(X, Y, 60, 'filled'); grid on; box on; text(X+1, Y+1.5, methods);
xlim([-2 45]); ylim([0 100]); xlabel('Honest clients excluded (% of client rounds)');
ylabel('Recall of the rare attack classes (%)');
