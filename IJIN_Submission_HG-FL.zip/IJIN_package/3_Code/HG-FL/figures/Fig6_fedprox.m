set(groot,'defaultAxesFontName','Arial','defaultAxesFontSize',10);
methods = {'FLTrust', 'Multi-Krum', 'Median', 'Trimmed mean', 'FedAvg + FT'};
Ycic = [59.83 58.98; 49.33 54.65; 42.23 42.80; 36.48 37.87; 27.26 28.93]; Hcic = 64.92;
Yton = [54.72 53.75; 43.34 46.82; 35.69 34.90; 27.66 28.00; 20.73 21.51]; Hton = 59.90;
Yedge = [59.09 59.58; 57.74 60.28; 52.59 53.33; 39.09 44.22; 23.10 23.65]; Hedge = 66.50;
names = {'CICIoT2023','TON_IoT','Edge-IIoTset'}; Ys = {Ycic, Yton, Yedge}; Hs = [Hcic Hton Hedge];
figure('Position',[100 100 1050 350]);
for i = 1:3, subplot(1,3,i); bar(Ys{i},'grouped'); hold on; yline(Hs(i),'--r','HG-FL'); grid on; box on;
  set(gca,'XTick',1:numel(methods),'XTickLabel',methods); ylim([0 75]); title(names{i}); end
subplot(1,3,1); ylabel('Mean macro-F1 under attack (%)');
legend({'Without proximal term','With proximal term'},'Location','southoutside','Orientation','horizontal');
