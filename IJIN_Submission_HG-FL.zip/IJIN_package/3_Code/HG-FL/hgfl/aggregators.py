"""Aggregation rules of the baselines. Every rule receives the updates U (clients x parameters) and the
sample counts n, and returns one global update; LAST['accepted'] marks the accepted clients."""
import numpy as np
from sklearn.cluster import DBSCAN

try:
    from sklearn.cluster import HDBSCAN
except ImportError:
    HDBSCAN = None

LAST = {'accepted': None}


def _mark(m, sel=None):
    if sel is None:
        LAST['accepted'] = None
    else:
        a = np.zeros(m, dtype=bool)
        a[np.asarray(sel)] = True
        LAST['accepted'] = a


def fedavg(U, n, **kw):
    LAST['accepted'] = np.ones(len(U), dtype=bool)
    w = np.asarray(n, float)
    return (w[:, None] * U).sum(0) / w.sum()


def median(U, n, **kw):
    _mark(len(U))
    return np.median(U, axis=0)


def trimmed_mean(U, n, beta=0.2, **kw):
    _mark(len(U))
    k = int(np.floor(beta * len(U)))
    S = np.sort(U, axis=0)
    return S[k:len(U) - k].mean(0) if len(U) - 2 * k > 0 else np.median(U, 0)


def _pairwise_sq(U):
    G = U @ U.T
    d = np.diag(G)
    return np.maximum(d[:, None] + d[None, :] - 2 * G, 0.0)


def krum(U, n, f=0, multi=False, **kw):
    """Krum / Multi-Krum (Blanchard et al., 2017)."""
    m = len(U)
    f = int(min(f, (m - 3) // 2)) if m > 3 else 0
    D = _pairwise_sq(U)
    k = max(m - f - 2, 1)
    scores = np.array([np.sort(D[i][np.arange(m) != i])[:k].sum() for i in range(m)])
    if not multi:
        _mark(m, [int(np.argmin(scores))])
        return U[int(np.argmin(scores))]
    sel = np.argsort(scores)[:max(m - f, 1)]
    out = fedavg(U[sel], np.asarray(n)[sel])
    _mark(m, sel)
    return out


def fltrust(U, n, server_update=None, **kw):
    """FLTrust (Cao et al., 2021): ReLU-cosine trust with respect to the server update."""
    g0 = server_update
    n0 = np.linalg.norm(g0) + 1e-12
    norms = np.linalg.norm(U, axis=1) + 1e-12
    ts = np.maximum((U @ g0) / (norms * n0), 0.0)
    _mark(len(U), np.where(ts > 0)[0])
    if ts.sum() == 0:
        return np.zeros_like(g0)
    Un = U * (n0 / norms)[:, None]
    return (ts[:, None] * Un).sum(0) / ts.sum()


def dbscan_filter(U, n, eps=0.5, **kw):
    """DBSCAN on the cosine distance; the largest cluster is averaged."""
    Un = U / (np.linalg.norm(U, axis=1, keepdims=True) + 1e-12)
    D = np.clip(1 - Un @ Un.T, 0, 2)
    lab = DBSCAN(eps=eps, min_samples=max(2, len(U) // 5), metric='precomputed').fit_predict(D)
    good = lab[lab >= 0]
    if len(good) == 0:
        return median(U, n)
    best = np.bincount(good).argmax()
    sel = lab == best
    out = fedavg(U[sel], np.asarray(n)[sel])
    _mark(len(U), np.where(sel)[0])
    return out


def bucketing(U, n, s=2, rng=None, **kw):
    """Bucketing (Karimireddy et al., 2022): random buckets of s updates, then the coordinate-wise median."""
    rng = rng or np.random.default_rng()
    perm = rng.permutation(len(U))
    B = np.stack([U[perm[i:i + s]].mean(0) for i in range(0, len(U), s)])
    out = np.median(B, axis=0)
    _mark(len(U))
    return out


def flame(U, n, lam=0.001, rng=None, **kw):
    """FLAME (Nguyen et al., 2022): HDBSCAN majority cluster, clipping to the median norm and Gaussian noise."""
    rng = rng or np.random.default_rng()
    m = len(U)
    Un = U / (np.linalg.norm(U, axis=1, keepdims=True) + 1e-12)
    D = np.clip(1 - Un @ Un.T, 0, 2).astype(np.float64)
    if HDBSCAN is not None and m >= 3:
        lab = HDBSCAN(min_cluster_size=m // 2 + 1, min_samples=1, metric='precomputed',
                      allow_single_cluster=True, copy=True).fit_predict(D)
        good = lab[lab >= 0]
        sel = np.where(lab == np.bincount(good).argmax())[0] if len(good) else np.arange(m)
    else:
        sel = np.arange(m)
    norms = np.linalg.norm(U, axis=1)
    S = np.median(norms)
    Uc = U[sel] * np.minimum(1.0, S / (norms[sel] + 1e-12))[:, None]
    out = Uc.mean(0) + rng.normal(0.0, lam * S, size=U.shape[1])
    _mark(m, sel)
    return out


def zeno(U, n, f=0, loss_fn=None, rho=5e-4, **kw):
    """Zeno (Xie et al., 2019): loss decrease on the seed set minus rho ||delta||^2; the best m - f are averaged."""
    m = len(U)
    base = loss_fn(None)
    scores = np.array([base - loss_fn(U[i]) - rho * float(U[i] @ U[i]) for i in range(m)])
    sel = np.argsort(-scores)[:max(m - int(f), 1)]
    out = U[sel].mean(0)
    _mark(m, sel)
    return out


RULES = {'fedavg': fedavg, 'median': median, 'trmean': trimmed_mean,
         'krum': krum, 'mkrum': lambda U, n, **kw: krum(U, n, multi=True, **kw),
         'fltrust': fltrust, 'dbscan': dbscan_filter, 'bucketing': bucketing, 'flame': flame, 'zeno': zeno}
