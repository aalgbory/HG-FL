"""Local training (FedAvg, FedProx, SCAFFOLD) and the attacks of the threat model."""
import numpy as np


def local_train(model, w_global, X, y, n_classes, epochs=1, lr=0.05, batch=64,
                mu=0.0, c_global=None, c_local=None, momentum=0.9, rng=None):
    """Mini-batch SGD from w_global; mu > 0 adds the FedProx term, c_global/c_local the SCAFFOLD correction."""
    rng = rng or np.random.default_rng()
    w = w_global.copy()
    v = np.zeros_like(w)
    steps = 0
    for _ in range(epochs):
        idx = rng.permutation(len(y))
        for i in range(0, len(idx), batch):
            b = idx[i:i + batch]
            model.set_flat(w)
            g = model.grad_flat(X[b], y[b], n_classes)
            if mu > 0:
                g = g + mu * (w - w_global)
            if c_global is not None:
                g = g + c_global - c_local
            v = momentum * v + g
            w = w - lr * v
            steps += 1
    return w, steps


ATTACKS = ('none', 'label_flip', 'scaling', 'backdoor', 'adaptive')


def poison_data(X, y, attack, benign=0, backdoor_cfg=None, rng=None):
    """Label flipping (attack samples relabelled as benign) and backdoor (triggered copies labelled as benign)."""
    if attack in ('label_flip', 'scaling', 'adaptive'):
        y = y.copy()
        y[y != benign] = benign
        return X, y
    if attack == 'backdoor':
        cfg = backdoor_cfg
        X, y = X.copy(), y.copy()
        src = np.where(y == cfg['source'])[0]
        others = np.where(y != cfg['source'])[0]
        k = max(len(src), 50)
        pick = rng.choice(src if len(src) else others, k, replace=True)
        Xt = X[pick].copy()
        Xt[:, cfg['features']] = cfg['value']
        X = np.vstack([X, Xt])
        y = np.concatenate([y, np.full(k, benign)])
        return X, y
    return X, y


def poison_update(delta, attack, rnd, rng, scale=10.0, alt_start=5):
    """Scaling multiplies the update by 10; the backdoor update is boosted by 3."""
    if attack == 'scaling':
        return delta * scale
    if attack == 'backdoor':
        return delta * 3.0
    return delta


def adaptive_is_active(rnd, alt_start=5):
    """The adaptive attacker is honest in the first rounds and then attacks in every even round."""
    return rnd >= alt_start and rnd % 2 == 0
