"""Loading, preprocessing and Dirichlet partitioning of CICIoT2023, Edge-IIoTset and TON_IoT.
The benign class is mapped to index 0."""
import glob
import os

import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler

CIC_FAMILY = {
    'BenignTraffic': 'Benign',
    'DictionaryBruteForce': 'BruteForce',
    'DNS_Spoofing': 'Spoofing', 'MITM-ArpSpoofing': 'Spoofing',
    'SqlInjection': 'Web', 'XSS': 'Web', 'CommandInjection': 'Web',
    'Uploading_Attack': 'Web', 'Backdoor_Malware': 'Web', 'BrowserHijacking': 'Web',
    'VulnerabilityScan': 'Recon',
}

CIC_FOLDER_ALIAS = {'Benign_Final': 'BenignTraffic', 'Benign': 'BenignTraffic'}

EDGE_DROP = ['frame.time', 'ip.src_host', 'ip.dst_host', 'arp.src.proto_ipv4',
             'arp.dst.proto_ipv4', 'http.file_data', 'http.request.full_uri',
             'icmp.transmit_timestamp', 'http.request.uri.query', 'tcp.options',
             'tcp.payload', 'tcp.srcport', 'tcp.dstport', 'udp.port', 'mqtt.msg',
             'Attack_label']

TON_DROP = ['ts', 'src_ip', 'dst_ip', 'src_port', 'dst_port', 'label',
            'dns_query', 'ssl_subject', 'ssl_issuer', 'http_uri', 'http_user_agent']


def _cic_family(lbl):
    if lbl in CIC_FAMILY:
        return CIC_FAMILY[lbl]
    for pre in ('DDoS', 'DoS', 'Mirai', 'Recon'):
        if lbl.startswith(pre):
            return pre
    return lbl


def _read(path, nrows=None):
    files = sorted(glob.glob(os.path.join(path, '*.csv'))) if os.path.isdir(path) else [path]
    if not files:
        raise FileNotFoundError(f'No CSV found at {path}')
    frames, left = [], nrows
    for f in files:
        df = pd.read_csv(f, low_memory=False, nrows=left)
        frames.append(df)
        if left is not None:
            left -= len(df)
            if left <= 0:
                break
    return pd.concat(frames, ignore_index=True)


def _is_class_folders(path):
    if not os.path.isdir(path) or glob.glob(os.path.join(path, '*.csv')):
        return False
    return any(glob.glob(os.path.join(path, d, '**', '*.csv'), recursive=True)
               for d in os.listdir(path) if os.path.isdir(os.path.join(path, d)))


def _read_class_folders(path, per_class, label_col='label'):
    """CICIoT2023 release with one sub-folder per class; at most per_class rows are read per class."""
    frames = []
    for d in sorted(os.listdir(path)):
        sub = os.path.join(path, d)
        if not os.path.isdir(sub):
            continue
        files = sorted(glob.glob(os.path.join(sub, '**', '*.csv'), recursive=True))
        if not files:
            continue
        lbl = CIC_FOLDER_ALIAS.get(d, d)
        got, parts = 0, []
        for f in files:
            df = pd.read_csv(f, low_memory=False, nrows=per_class - got)
            df.columns = [c.strip() for c in df.columns]
            parts.append(df)
            got += len(df)
            if got >= per_class:
                break
        df = pd.concat(parts, ignore_index=True)
        df = df.drop(columns=[c for c in df.columns if c.lower() == 'label'], errors='ignore')
        df[label_col] = lbl
        frames.append(df)
        print(f'  {lbl:28s} {len(df):>8d} rows from {min(len(files), len(parts))} file(s)')
    return pd.concat(frames, ignore_index=True)


def load_dataset(name, path, max_per_class=20000, nrows=None, seed=0):
    if name == 'ciciot2023' and _is_class_folders(path):
        print('CICIoT2023 per-class folders detected:')
        df = _read_class_folders(path, per_class=max_per_class or 20000)
    else:
        df = _read(path, nrows)
    df.columns = [c.strip() for c in df.columns]
    if name == 'ciciot2023':
        y_raw = df['label'].astype(str).map(_cic_family)
        X = df.drop(columns=['label'])
        benign = 'Benign'
    elif name == 'edge_iiotset':
        y_raw = df['Attack_type'].astype(str)
        X = df.drop(columns=[c for c in EDGE_DROP + ['Attack_type'] if c in df.columns])
        benign = 'Normal'
    elif name == 'ton_iot':
        y_raw = df['type'].astype(str)
        X = df.drop(columns=[c for c in TON_DROP + ['type'] if c in df.columns])
        benign = 'normal'
    else:
        raise ValueError(f'unknown dataset {name}')

    num = X.select_dtypes(include=[np.number])
    cat = [c for c in X.columns if c not in num.columns and X[c].nunique() <= 50]
    if cat:
        num = pd.concat([num, pd.get_dummies(X[cat].astype(str), dtype=float)], axis=1)
    num = num.replace([np.inf, -np.inf], np.nan).fillna(0.0)
    num = num.loc[:, num.std() > 0]

    rng = np.random.default_rng(seed)
    keep = []
    for c, idx in y_raw.groupby(y_raw).groups.items():
        idx = np.asarray(idx)
        if len(idx) > max_per_class:
            idx = rng.choice(idx, max_per_class, replace=False)
        keep.append(idx)
    keep = np.sort(np.concatenate(keep))
    Xv = num.loc[keep].to_numpy(dtype=np.float32)
    yv = y_raw.loc[keep].to_numpy()

    classes = sorted(set(yv))
    if benign in classes:
        classes.remove(benign)
        classes = [benign] + classes
    cmap = {c: i for i, c in enumerate(classes)}
    y = np.array([cmap[v] for v in yv], dtype=np.int64)
    return Xv, y, classes


def split_and_scale(X, y, test_size=0.2, seed=0):
    Xtr, Xte, ytr, yte = train_test_split(X, y, test_size=test_size,
                                          stratify=y, random_state=seed)
    sc = StandardScaler().fit(Xtr)
    Xtr = np.clip(sc.transform(Xtr), -10, 10).astype(np.float32)
    Xte = np.clip(sc.transform(Xte), -10, 10).astype(np.float32)
    return Xtr, Xte, ytr, yte


def dirichlet_partition(y, n_clients, alpha, seed=0, min_size=20):
    """Label-skew partition: every class is split across the clients by Dir(alpha); alpha <= 0 gives IID."""
    rng = np.random.default_rng(seed)
    n_classes = int(y.max()) + 1
    if alpha is None or alpha <= 0:
        idx = rng.permutation(len(y))
        return [list(s) for s in np.array_split(idx, n_clients)]
    for _ in range(100):
        parts = [[] for _ in range(n_clients)]
        for c in range(n_classes):
            idx = rng.permutation(np.where(y == c)[0])
            p = rng.dirichlet(alpha * np.ones(n_clients))
            cuts = (np.cumsum(p) * len(idx)).astype(int)[:-1]
            for k, chunk in enumerate(np.split(idx, cuts)):
                parts[k] += chunk.tolist()
        if min(len(p) for p in parts) >= min_size:
            return parts
    return parts

