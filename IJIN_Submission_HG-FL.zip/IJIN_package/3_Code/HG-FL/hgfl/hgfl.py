"""HG-FL server aggregation.

The final framework (sub-sections 4.4-4.7 of the article) uses the norm guard, the leave-one-out utility on the
seed set, the reputation memory and uniform client weights; the server fine-tuning is applied in simulate.py.
The first design additionally used direction grouping with robust group centres, a class-balanced utility,
member rescue, isolation and norm clipping; these switches are kept for the ablation of sub-section 5.7.
"""
import numpy as np
from sklearn.cluster import AgglomerativeClustering


def _per_class_loss(model, w, X, y, n_classes, class_balanced=True):
    model.set_flat(w)
    p = model.predict_proba(X)
    ll = -np.log(np.clip(p[np.arange(len(y)), y], 1e-12, 1.0))
    if not class_balanced:
        return np.array([ll.mean()])
    out = np.full(n_classes, np.nan)
    for c in range(n_classes):
        m = y == c
        if m.any():
            out[c] = ll[m].mean()
    return out


class HGFL:
    def __init__(self, n_clients, n_classes, model, X_seed, y_seed, clip_mult=2.0,
                 dist_threshold=0.6, beta_trim=0.1, gamma=0.7, tol=1.0, kappa=0.05, rep_thr=-0.1,
                 use_clustering=True, use_reputation=True, use_clipping=True,
                 class_balanced=True, use_rescue=True, use_isolation=True, norm_guard=None):
        self.K, self.C = n_clients, n_classes
        self.model, self.Xs, self.ys = model, X_seed, y_seed
        self.rep = np.zeros(n_clients)
        self.seen = np.zeros(n_clients, dtype=bool)
        self.clip_mult = clip_mult
        self.dist_threshold = dist_threshold
        self.beta_trim = beta_trim
        self.gamma = gamma
        self.tol = tol
        self.kappa = kappa
        self.rep_thr = rep_thr
        self.use_clustering = use_clustering
        self.use_reputation = use_reputation
        self.use_clipping = use_clipping
        self.class_balanced = class_balanced
        self.use_rescue = use_rescue
        self.use_isolation = use_isolation
        self.norm_guard = norm_guard
        self.flags = np.zeros(n_clients, int)
        self.last_info = None
        self.last_groups = None
        self.last_scores = None

    def _robust_center(self, G, n):
        m = len(G)
        if m >= 5:
            k = int(np.floor(self.beta_trim * m))
            S = np.sort(G, axis=0)
            return S[k:m - k].mean(0)
        if m >= 3:
            return np.median(G, axis=0)
        return (n[:, None] * G).sum(0) / n.sum()

    def _macro_loss(self, w):
        l = _per_class_loss(self.model, w, self.Xs, self.ys, self.C, self.class_balanced)
        return l[~np.isnan(l)]

    def __call__(self, U, n, client_ids, w=None, **kw):
        U = np.asarray(U, float).copy()
        n = np.asarray(n, float)
        ids = np.asarray(client_ids)
        m = len(U)

        raw = np.linalg.norm(U, axis=1)
        flagged = (raw > self.norm_guard * np.median(raw)) if self.norm_guard else np.zeros(m, dtype=bool)
        self.flags[ids[flagged]] += 1
        flagged = flagged | (self.flags[ids] >= 2)
        if self.use_clipping:
            norms = raw
            tau = np.median(norms) * self.clip_mult
            U *= np.minimum(1.0, tau / (norms + 1e-12))[:, None]

        Un = U / (np.linalg.norm(U, axis=1, keepdims=True) + 1e-12)
        Cs = Un @ Un.T
        np.fill_diagonal(Cs, -1.0)
        iso_client = (Cs.max(1) < self.kappa) if self.use_isolation else np.zeros(m, dtype=bool)
        if self.use_clustering and m >= 4:
            D = np.clip(1.0 - Un @ Un.T, 0.0, 2.0)
            groups = AgglomerativeClustering(n_clusters=None, metric='precomputed', linkage='average',
                                             distance_threshold=self.dist_threshold).fit_predict(D)
        else:
            groups = np.arange(m)
        if flagged.any():
            groups = groups.copy()
            groups[flagged] = groups.max() + 1 + np.arange(flagged.sum())
            iso_client = iso_client | flagged
        self.last_groups = groups
        gids = np.unique(groups)
        G = len(gids)
        centers = np.stack([self._robust_center(U[groups == g], n[groups == g]) for g in gids])
        sizes = np.array([n[groups == g].sum() for g in gids])
        isolated = np.array([iso_client[groups == g].all() for g in gids])

        def agg(mask):
            ww = sizes * mask
            return (ww[:, None] * centers).sum(0) / ww.sum()
        active = np.ones(G)
        if self.use_reputation:
            known = np.array([self.seen[ids[groups == g]].all() for g in gids])
            prior = np.array([self.rep[ids[groups == g]].mean() for g in gids])
            active = np.where(known & (prior <= self.rep_thr), 0.0, 1.0)
            if active.sum() == 0:
                active = np.ones(G)
        scores = np.zeros(G)
        for _ in range(2):
            full = self._macro_loss(w + agg(active))
            for gi in range(G):
                if active.sum() <= 1 and active[gi] == 1:
                    scores[gi] = 0.0
                    continue
                mask = active.copy()
                mask[gi] = 1.0 - mask[gi]
                other = self._macro_loss(w + agg(mask))
                delta = np.mean(other - full)
                scores[gi] = delta if active[gi] == 1 else -delta
            zz = scores / (float(np.mean(full)) + 1e-12)
            new_active = (zz > -self.tol).astype(float)
            if new_active.sum() == 0 or np.array_equal(new_active, active):
                break
            active = new_active
        self.last_scores = scores
        scale = float(np.mean(full)) + 1e-12
        zg = np.clip(scores / scale, -5.0, 5.0)

        units = []
        for gi, g in enumerate(gids):
            pos = np.where(groups == g)[0]
            if isolated[gi]:
                units.append((centers[gi], sizes[gi], pos, min(zg[gi], -self.tol - 1)))
            elif zg[gi] > -self.tol or len(pos) == 1:
                units.append((centers[gi], sizes[gi], pos, zg[gi]))
        base_units = [u for u in units if u[3] > -self.tol]

        def agg_units(us):
            wsum = sum(u[1] for u in us)
            return sum(u[1] * u[0] for u in us) / wsum

        ref_loss = self._macro_loss(w + agg_units(base_units)) if base_units else self._macro_loss(w)
        for gi, g in enumerate(gids):
            pos = np.where(groups == g)[0]
            if not self.use_rescue or isolated[gi] or zg[gi] > -self.tol or len(pos) == 1:
                continue
            for p_ in pos:
                single = (U[p_], n[p_], np.array([p_]), 0.0)
                cand = self._macro_loss(w + agg_units(base_units + [single]))
                zi = float(np.clip(np.mean(ref_loss - cand) / scale, -5.0, 5.0))
                units.append((U[p_], n[p_], np.array([p_]), zi if zi > 0 else min(zi, -self.tol - 1e-6)))

        zc = np.zeros(m)
        for u in units:
            zc[u[2]] = u[3]
        if self.use_reputation:
            step = np.where(zc >= 0, zc, 2.0 * zc)
            fresh = ~self.seen[ids]
            self.rep[ids[fresh]] = step[fresh]
            old = ~fresh
            self.rep[ids[old]] = self.gamma * self.rep[ids[old]] + (1 - self.gamma) * step[old]
            self.seen[ids] = True
            trust_c = self.rep[ids]
        else:
            trust_c = zc

        final = []
        accepted = np.zeros(m, dtype=bool)
        rescued = np.zeros(m, dtype=bool)
        for u in units:
            f = float(np.clip(1.0 + trust_c[u[2]].mean(), 0.0, 1.0)) if self.use_reputation else 1.0
            if u[3] > -self.tol and f > 0:
                final.append((u[0], u[1] * f, u[2], u[3]))
                accepted[u[2]] = True
                if len(u[2]) == 1 and len(np.where(groups == groups[u[2][0]])[0]) > 1:
                    rescued[u[2]] = True
        self.last_info = dict(flagged=flagged, isolated=iso_client.copy(), accepted=accepted, rescued=rescued)
        if not final:
            return np.zeros(U.shape[1])
        return agg_units(final)
