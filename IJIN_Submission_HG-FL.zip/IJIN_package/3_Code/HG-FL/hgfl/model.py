"""Multilayer perceptron in NumPy with flat-parameter access."""
import numpy as np


class MLP:
    def __init__(self, sizes, seed=0):
        rng = np.random.default_rng(seed)
        self.sizes = list(sizes)
        self.params = []
        for a, b in zip(sizes[:-1], sizes[1:]):
            W = rng.normal(0.0, np.sqrt(2.0 / a), size=(a, b))
            self.params += [W, np.zeros(b)]
        self.shapes = [p.shape for p in self.params]
        self.n_params = int(sum(p.size for p in self.params))

    def get_flat(self):
        return np.concatenate([p.ravel() for p in self.params])

    def set_flat(self, v):
        i = 0
        for k, s in enumerate(self.shapes):
            n = int(np.prod(s))
            self.params[k] = v[i:i + n].reshape(s).copy()
            i += n

    def forward(self, X):
        acts = [X]
        h = X
        L = len(self.params) // 2
        for l in range(L):
            W, b = self.params[2 * l], self.params[2 * l + 1]
            z = h @ W + b
            h = np.maximum(z, 0.0) if l < L - 1 else z
            acts.append(h)
        return acts

    def predict_proba(self, X, batch=8192):
        out = []
        for i in range(0, len(X), batch):
            z = self.forward(X[i:i + batch])[-1]
            z = z - z.max(1, keepdims=True)
            e = np.exp(z)
            out.append(e / e.sum(1, keepdims=True))
        return np.vstack(out)

    def predict(self, X):
        return self.predict_proba(X).argmax(1)

    def grad_flat(self, X, y, n_classes):
        """Gradient of the mean cross-entropy as one flat vector."""
        acts = self.forward(X)
        z = acts[-1]
        z = z - z.max(1, keepdims=True)
        p = np.exp(z)
        p /= p.sum(1, keepdims=True)
        p[np.arange(len(y)), y] -= 1.0
        delta = p / len(y)
        L = len(self.params) // 2
        grads = [None] * len(self.params)
        for l in range(L - 1, -1, -1):
            h = acts[l]
            grads[2 * l] = h.T @ delta
            grads[2 * l + 1] = delta.sum(0)
            if l > 0:
                delta = (delta @ self.params[2 * l].T) * (acts[l] > 0)
        return np.concatenate([g.ravel() for g in grads])
