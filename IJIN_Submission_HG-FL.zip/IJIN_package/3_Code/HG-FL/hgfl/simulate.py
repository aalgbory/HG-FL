"""Federated simulation loop.

Method names: fedavg fedprox scaffold krum mkrum median trmean dbscan bucketing flame fltrust zeno, the controls
fedavg_ft and mkrum_ft (server fine-tuning on the seed set), hgfl (final framework) and its ablations hgfl_noft,
hgfl_noguard and hgfl_norep, and hgfl_v1 (first design) with its ablations. The suffix '+prox' adds the FedProx
term to the local training. HG-FL options are given after '@', e.g. 'hgfl_v1@w=uniform,ft=1,rho=2':
w (client weights n | sqrt | uniform), ft (1 = server fine-tuning), rho (norm guard), tau, gamma, seed
(seed samples per class).
"""
import time

import numpy as np
from sklearn.metrics import accuracy_score, f1_score, recall_score

from . import aggregators as AG
from .aggregators import RULES
from .clients import local_train, poison_data, poison_update, adaptive_is_active
from .hgfl import HGFL, _per_class_loss
from .model import MLP

BASELINES = ('fedavg', 'fedprox', 'scaffold', 'krum', 'mkrum', 'median', 'trmean', 'dbscan', 'bucketing', 'flame',
             'fltrust', 'zeno')
CONTROLS = ('fedavg_ft', 'mkrum_ft')
_FINAL = dict(use_clustering=False, use_clipping=False, use_isolation=False, use_rescue=False, class_balanced=False)
# name -> (HGFL switches, default options, proximal term in the local training)
HG_VARIANTS = {
    'hgfl': (_FINAL, {'w': 'uniform', 'ft': 1.0, 'rho': 2.0}, False),
    'hgfl_noft': (_FINAL, {'w': 'uniform', 'rho': 2.0}, False),
    'hgfl_noguard': (_FINAL, {'w': 'uniform', 'ft': 1.0}, False),
    'hgfl_norep': (dict(_FINAL, use_reputation=False), {'w': 'uniform', 'ft': 1.0, 'rho': 2.0}, False),
    'hgfl_v1': ({}, {}, True),
    'hgfl_v1_nogroup': (dict(use_clustering=False), {}, True),
    'hgfl_v1_sampleavg': (dict(class_balanced=False), {}, True),
    'hgfl_v1_norescue': (dict(use_rescue=False), {}, True),
    'hgfl_v1_noclip': (dict(use_clipping=False), {}, True),
    'hgfl_v1_noprox': ({}, {}, False),
}
METHODS = BASELINES + CONTROLS + tuple(HG_VARIANTS)


def parse_method(name):
    """'fltrust+prox' -> ('fltrust', True, {}); 'hgfl_v1@tau=0.5' -> ('hgfl_v1', False, {'tau': 0.5})."""
    over = {}
    if '@' in name:
        name, spec = name.split('@', 1)
        for kv in spec.split(','):
            k, v = kv.split('=')
            over[k] = v if k == 'w' else float(v)
    prox_all = name.endswith('+prox')
    base = name[:-5] if prox_all else name
    if base not in METHODS:
        raise ValueError(f'unknown method {name}')
    if base in HG_VARIANTS:
        over = {**HG_VARIANTS[base][1], **over}
    return base, prox_all, over


def rare_classes_of(ytr, n_classes, benign=0):
    """Attack classes whose training count is below half of the median attack class."""
    cnt = np.bincount(ytr, minlength=n_classes)
    att = [c for c in range(n_classes) if c != benign and cnt[c] > 0]
    med = np.median([cnt[c] for c in att])
    return [int(c) for c in att if cnt[c] < 0.5 * med]


def evaluate(model, X, y, n_classes, benign=0, backdoor_cfg=None):
    pred = model.predict(X)
    out = {
        'accuracy': accuracy_score(y, pred),
        'macro_f1': f1_score(y, pred, average='macro', labels=range(n_classes), zero_division=0),
        'weighted_f1': f1_score(y, pred, average='weighted', zero_division=0),
    }
    rec = recall_score(y, pred, average=None, labels=range(n_classes), zero_division=0)
    out['per_class_recall'] = [float(r) for r in rec]
    bmask = y == benign
    out['far'] = float((pred[bmask] != benign).mean()) if bmask.any() else 0.0
    amask = ~bmask
    out['detection_rate'] = float((pred[amask] != benign).mean()) if amask.any() else 0.0
    if backdoor_cfg is not None:
        src = np.where(y == backdoor_cfg['source'])[0]
        if len(src):
            Xt = X[src].copy()
            Xt[:, backdoor_cfg['features']] = backdoor_cfg['value']
            out['asr'] = float((model.predict(Xt) == benign).mean())
    return out


def run_federated(Xtr, ytr, Xte, yte, parts, n_classes, method='hgfl', attack='none',
                  mal_frac=0.0, rounds=40, local_epochs=1, lr=0.05, batch=64, mu=0.01,
                  hidden=(128, 64), frac_fit=1.0, seed=0, benign=0, log_every=5):
    base, prox_all, over = parse_method(method)
    rng = np.random.default_rng(seed)
    K = len(parts)
    d = Xtr.shape[1]
    model = MLP([d, *hidden, n_classes], seed=seed)
    w = model.get_flat()

    n_mal = int(round(mal_frac * K)) if attack != 'none' else 0
    malicious = set(rng.choice(K, n_mal, replace=False).tolist()) if n_mal else set()

    backdoor_cfg = None
    if attack == 'backdoor':
        counts = np.bincount(ytr, minlength=n_classes)
        attack_classes = [c for c in range(n_classes) if c != benign and counts[c] > 0]
        src = min(attack_classes, key=lambda c: counts[c])
        backdoor_cfg = {'source': int(src), 'features': list(range(min(3, d))), 'value': 4.0}

    seed_pc = int(over.get('seed', 20))
    root_idx = np.concatenate([rng.choice(np.where(ytr == c)[0], min(seed_pc, (ytr == c).sum()), replace=False)
                               for c in range(n_classes) if (ytr == c).any()])
    Xr, yr = Xtr[root_idx], ytr[root_idx]

    is_hg = base.startswith('hgfl')
    agg = None
    if is_hg:
        kw = dict(HG_VARIANTS[base][0])
        for k_, a_ in (('tau', 'tol'), ('gamma', 'gamma'), ('eps', 'rep_thr'), ('rho', 'norm_guard')):
            if k_ in over:
                kw[a_] = over[k_]
        agg = HGFL(K, n_classes, MLP([d, *hidden, n_classes], seed=seed), Xr, yr, **kw)
    use_prox = prox_all or base == 'fedprox' or (is_hg and HG_VARIANTS[base][2])
    prox = mu if use_prox and base != 'scaffold' else 0.0
    wmode = over.get('w', 'n')

    eval_model = MLP([d, *hidden, n_classes], seed=seed)

    def seed_loss(delta):
        return float(_per_class_loss(eval_model, w if delta is None else w + delta, Xr, yr, n_classes, False)[0])

    cls_counts = np.stack([np.bincount(ytr[p], minlength=n_classes) for p in parts])
    n_part = np.zeros(K, int)
    n_excl = np.zeros(K, int)
    n_iso = np.zeros(K, int)
    n_resc = np.zeros(K, int)
    n_flag = np.zeros(K, int)
    coordinate_wise = False

    c_glob = np.zeros_like(w) if base == 'scaffold' else None
    c_loc = [np.zeros_like(w) for _ in range(K)] if base == 'scaffold' else None
    history = []
    t0 = time.time()
    t_server = 0.0
    for rnd in range(rounds):
        sel = rng.choice(K, max(1, int(frac_fit * K)), replace=False)
        U, nk, ids, dc = [], [], [], []
        for k in sel:
            Xk, yk = Xtr[parts[k]], ytr[parts[k]]
            if len(yk) == 0:
                continue
            bad = k in malicious and (attack != 'adaptive' or adaptive_is_active(rnd))
            a = attack if bad else 'none'
            if a != 'none':
                Xk, yk = poison_data(Xk, yk, a, benign, backdoor_cfg, rng)
            cg = c_glob if base == 'scaffold' else None
            cl = c_loc[k] if base == 'scaffold' else None
            wk, steps = local_train(model, w, Xk, yk, n_classes, local_epochs, lr, batch,
                                    mu=prox, c_global=cg, c_local=cl, rng=rng,
                                    momentum=0.0 if base == 'scaffold' else 0.9)
            delta = wk - w
            if a != 'none':
                delta = poison_update(delta, 'scaling' if a == 'adaptive' else a, rnd, rng)
            if base == 'scaffold':
                c_new = cl - c_glob + (w - wk) / (max(steps, 1) * lr)
                dc.append(c_new - cl)
                c_loc[k] = c_new
            U.append(delta)
            nk.append(len(parts[k]))
            ids.append(k)
        U = np.stack(U)
        ids_a = np.asarray(ids)

        ts = time.time()
        AG.LAST['accepted'] = None
        if is_hg:
            wts = np.sqrt(nk) if wmode == 'sqrt' else (np.ones(len(nk)) if wmode == 'uniform' else np.asarray(nk, float))
            upd = agg(U, wts, ids, w=w)
            info = agg.last_info
            accepted = info['accepted']
            n_iso[ids_a[info['isolated']]] += 1
            n_flag[ids_a[info['flagged']]] += 1
            n_resc[ids_a[info['rescued']]] += 1
            if over.get('ft'):
                ep = max(1, int(np.ceil(np.median(nk) / len(root_idx))))
                w1, _ = local_train(model, w + upd, Xr, yr, n_classes, ep, lr, batch, rng=rng)
                upd = w1 - w
        elif base in ('fedavg', 'fedprox', 'scaffold'):
            upd = RULES['fedavg'](U, nk)
            accepted = AG.LAST['accepted']
        elif base == 'fltrust':
            ep = max(1, int(np.ceil(np.median(nk) / len(root_idx))))
            w0, _ = local_train(model, w, Xr, yr, n_classes, ep, lr, batch, rng=rng)
            upd = RULES['fltrust'](U, nk, server_update=w0 - w)
            accepted = AG.LAST['accepted']
        elif base in ('fedavg_ft', 'mkrum_ft'):
            upd = RULES['fedavg'](U, nk) if base == 'fedavg_ft' else RULES['mkrum'](U, nk, f=n_mal)
            accepted = AG.LAST['accepted']
            ep = max(1, int(np.ceil(np.median(nk) / len(root_idx))))
            w1, _ = local_train(model, w + upd, Xr, yr, n_classes, ep, lr, batch, rng=rng)
            upd = w1 - w
        elif base == 'zeno':
            upd = RULES['zeno'](U, nk, f=n_mal, loss_fn=seed_loss)
            accepted = AG.LAST['accepted']
        elif base in ('bucketing', 'flame'):
            upd = RULES[base](U, nk, rng=rng)
            accepted = AG.LAST['accepted']
        else:
            upd = RULES[base](U, nk, f=n_mal)
            accepted = AG.LAST['accepted']
        t_server += time.time() - ts

        n_part[ids_a] += 1
        if accepted is None:
            coordinate_wise = True
        else:
            n_excl[ids_a[~np.asarray(accepted, bool)]] += 1

        w = w + upd
        if base == 'scaffold' and dc:
            c_glob = c_glob + np.mean(dc, axis=0) * (len(dc) / K)
        if log_every and ((rnd + 1) % log_every == 0 or rnd == rounds - 1):
            model.set_flat(w)
            m = evaluate(model, Xte, yte, n_classes, benign, backdoor_cfg)
            history.append({'round': rnd + 1, 'macro_f1': m['macro_f1'], 'accuracy': m['accuracy']})

    model.set_flat(w)
    res = evaluate(model, Xte, yte, n_classes, benign, backdoor_cfg)
    res.update({'time_s': time.time() - t0, 'server_time_s': t_server, 'n_params': model.n_params,
                'upload_floats_per_round': int(model.n_params * len(sel)),
                'malicious_clients': sorted(int(x) for x in malicious),
                'backdoor_source': backdoor_cfg['source'] if backdoor_cfg else None,
                'prox': bool(prox > 0), 'weights': wmode if is_hg else 'n', 'seed_per_class': seed_pc,
                'rare_classes': rare_classes_of(ytr, n_classes, benign),
                'client_counts': cls_counts.tolist(),
                'client_participation': n_part.tolist(),
                'client_excluded': None if coordinate_wise else n_excl.tolist(),
                'client_isolated': n_iso.tolist() if is_hg else None,
                'client_rescued': n_resc.tolist() if is_hg else None,
                'client_flagged': n_flag.tolist() if is_hg else None,
                'history': history})
    return res
