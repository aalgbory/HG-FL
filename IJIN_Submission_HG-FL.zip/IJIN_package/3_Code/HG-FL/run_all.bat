@echo off
set CIC=path\to\CICIoT2023
set TON=path\to\Train_Test_Network.csv
set EDGE=path\to\ML-EdgeIIoT-dataset.csv
for %%g in (tuning guard) do (
  python run_experiments.py --dataset ciciot2023 --data %CIC% --grid %%g --val --out results\%%g_cic.jsonl
  python run_experiments.py --dataset ton_iot --data %TON% --grid %%g --val --out results\%%g_ton.jsonl
  python run_experiments.py --dataset edge_iiotset --data %EDGE% --grid %%g --val --out results\%%g_edge.jsonl
)
for %%g in (main prox ablation ablation_v1 iid skew) do (
  python run_experiments.py --dataset ciciot2023 --data %CIC% --grid %%g --out results\%%g_cic.jsonl
  python run_experiments.py --dataset ton_iot --data %TON% --grid %%g --out results\%%g_ton.jsonl
  python run_experiments.py --dataset edge_iiotset --data %EDGE% --grid %%g --out results\%%g_edge.jsonl
)
python run_central.py --dataset ciciot2023 --data %CIC% --out results\central_cic.jsonl
python run_central.py --dataset ton_iot --data %TON% --out results\central_ton.jsonl
python run_central.py --dataset edge_iiotset --data %EDGE% --out results\central_edge.jsonl
cd analysis
python make_tables.py
python make_figures.py
