"""Centralised reference of Table 10: the same MLP trained on the pooled training part.

Example:
  python run_central.py --dataset ciciot2023 --data path/to/CSV --out results/central_cic.jsonl
"""
import argparse
import json
import os
import time

import numpy as np
from sklearn.model_selection import train_test_split

from hgfl.clients import local_train
from hgfl.data import load_dataset, split_and_scale
from hgfl.model import MLP
from hgfl.simulate import evaluate


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--dataset', required=True, choices=['ciciot2023', 'edge_iiotset', 'ton_iot'])
    ap.add_argument('--data', required=True)
    ap.add_argument('--max-per-class', type=int, default=20000)
    ap.add_argument('--nrows', type=int, default=None)
    ap.add_argument('--seeds', nargs='+', type=int, default=[0, 1, 2, 3, 4])
    ap.add_argument('--val-frac', type=float, default=0.1)
    ap.add_argument('--epochs', type=int, default=40)
    ap.add_argument('--lr', type=float, default=0.05)
    ap.add_argument('--out', required=True)
    args = ap.parse_args()

    os.makedirs(os.path.dirname(args.out) or '.', exist_ok=True)
    done = set()
    if os.path.exists(args.out):
        for line in open(args.out):
            r = json.loads(line)
            done.add((r['dataset'], r['seed'], r['epochs']))

    X, y, classes = load_dataset(args.dataset, args.data, args.max_per_class, args.nrows)
    C = len(classes)
    for seed in args.seeds:
        if (args.dataset, seed, args.epochs) in done:
            continue
        Xtr, Xte, ytr, yte = split_and_scale(X, y, seed=seed)
        Xtr, _, ytr, _ = train_test_split(Xtr, ytr, test_size=args.val_frac, stratify=ytr, random_state=seed)
        rng = np.random.default_rng(seed)
        model = MLP([X.shape[1], 128, 64, C], seed=seed)
        t0 = time.time()
        w, _ = local_train(model, model.get_flat(), Xtr, ytr, C, args.epochs, args.lr, 64, rng=rng)
        model.set_flat(w)
        m = evaluate(model, Xte, yte, C)
        row = dict(dataset=args.dataset, method='centralized', seed=seed, epochs=args.epochs,
                   time_s=time.time() - t0, classes=classes,
                   **{k: (v.tolist() if hasattr(v, 'tolist') else v) for k, v in m.items()})
        with open(args.out, 'a') as f:
            f.write(json.dumps(row) + '\n')
        print(f"centralized seed={seed} macroF1={row['macro_f1']:.4f}")


if __name__ == '__main__':
    main()
