"""Runs the experiment grids of the article and appends one JSON line per run.

Example:
  python run_experiments.py --dataset ciciot2023 --data path/to/CSV --grid main --out results/main_cic.jsonl
"""
import argparse
import itertools
import json
import os

import numpy as np
from sklearn.model_selection import train_test_split

from hgfl.data import load_dataset, split_and_scale, dirichlet_partition
from hgfl.simulate import run_federated, BASELINES, CONTROLS

ATT3 = ['label_flip', 'scaling', 'adaptive']
S5 = [0, 1, 2, 3, 4]
GRIDS = {
    # Table 3 (run with --val)
    'tuning': dict(methods=['hgfl_v1', 'hgfl_v1@w=uniform', 'hgfl_v1@w=sqrt', 'hgfl_v1@tau=0.5', 'hgfl_v1@tau=2.0',
                            'hgfl_v1@gamma=0.5', 'hgfl_v1@gamma=0.9', 'hgfl_v1@seed=5', 'hgfl_v1@seed=10',
                            'hgfl_v1@seed=50'],
                   alphas=[0.1], attacks=['none'] + ATT3, mal=[0.4], seeds=[0, 1]),
    # Table 4 (run with --val)
    'guard': dict(methods=['hgfl_v1@w=uniform,ft=1', 'hgfl_v1@w=uniform,ft=1,rho=1.5', 'hgfl_v1@w=uniform,ft=1,rho=2',
                           'hgfl_v1@w=uniform,ft=1,rho=2.5'],
                  alphas=[0.1], attacks=['none'] + ATT3 + ['backdoor'], mal=[0.4], seeds=[0, 1]),
    # Tables 5-8 and 12, figures 2-5
    'main': dict(methods=list(BASELINES) + list(CONTROLS) + ['hgfl'], alphas=[0.1],
                 attacks=['none'] + ATT3 + ['backdoor'], mal=[0.3, 0.4], seeds=S5),
    # Figure 6
    'prox': dict(methods=['fltrust+prox', 'mkrum+prox', 'median+prox', 'trmean+prox', 'fedavg_ft+prox'],
                 alphas=[0.1], attacks=['none'] + ATT3, mal=[0.3, 0.4], seeds=S5),
    # Table 9
    'ablation': dict(methods=['hgfl_noft', 'hgfl_noguard', 'hgfl_norep'], alphas=[0.1],
                     attacks=ATT3 + ['backdoor'], mal=[0.4], seeds=S5),
    # sub-section 5.7, components of the first design
    'ablation_v1': dict(methods=[m + '@w=uniform,ft=1,rho=2' for m in ('hgfl_v1', 'hgfl_v1_nogroup',
                                                                       'hgfl_v1_sampleavg', 'hgfl_v1_norescue',
                                                                       'hgfl_v1_noclip', 'hgfl_v1_noprox')],
                        alphas=[0.1], attacks=ATT3 + ['backdoor'], mal=[0.4], seeds=S5),
    # Table 10 (alpha = 0 means IID)
    'iid': dict(methods=['fedavg', 'hgfl'], alphas=[0.0], attacks=['none'], mal=[0.0], seeds=S5),
    # Table 11
    'skew': dict(methods=['fedavg', 'median', 'mkrum', 'fltrust', 'zeno', 'mkrum_ft', 'hgfl'], alphas=[0.5, 1.0],
                 attacks=ATT3, mal=[0.4], seeds=[0, 1, 2]),
}


def key_of(r):
    return (r['dataset'], r['method'], r['alpha'], r['attack'], r['mal_frac'], r['seed'], r['clients'])


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--dataset', required=True, choices=['ciciot2023', 'edge_iiotset', 'ton_iot'])
    ap.add_argument('--data', required=True, help='CSV file or folder of CSV files')
    ap.add_argument('--max-per-class', type=int, default=20000)
    ap.add_argument('--nrows', type=int, default=None)
    ap.add_argument('--grid', required=True, choices=list(GRIDS))
    ap.add_argument('--clients', type=int, default=20)
    ap.add_argument('--rounds', type=int, default=40)
    ap.add_argument('--out', required=True)
    ap.add_argument('--val', action='store_true', help='evaluate on the validation split')
    ap.add_argument('--val-frac', type=float, default=0.1)
    ap.add_argument('--worker', type=int, default=0)
    ap.add_argument('--workers', type=int, default=1)
    args = ap.parse_args()
    cfg = GRIDS[args.grid]

    if args.workers > 1:
        root, ext = os.path.splitext(args.out)
        args.out = f'{root}_w{args.worker}{ext}'
    os.makedirs(os.path.dirname(args.out) or '.', exist_ok=True)
    done = set()
    if os.path.exists(args.out):
        with open(args.out) as f:
            for line in f:
                done.add(key_of(json.loads(line)))

    X, y, classes = load_dataset(args.dataset, args.data, args.max_per_class, args.nrows)
    print(f'{len(y)} samples, {X.shape[1]} features, {len(classes)} classes:',
          dict(zip(classes, np.bincount(y).tolist())))

    K = args.clients
    job = -1
    for seed in cfg['seeds']:
        Xtr, Xte, ytr, yte = split_and_scale(X, y, seed=seed)
        Xtr, Xva, ytr, yva = train_test_split(Xtr, ytr, test_size=args.val_frac, stratify=ytr, random_state=seed)
        if args.val:
            Xte, yte = Xva, yva
        for alpha in cfg['alphas']:
            parts = dirichlet_partition(ytr, K, alpha, seed=seed)
            for attack, mal, method in itertools.product(cfg['attacks'], cfg['mal'], cfg['methods']):
                if attack == 'none' and mal != cfg['mal'][0]:
                    continue
                mf = 0.0 if attack == 'none' else mal
                row = dict(dataset=args.dataset, method=method, alpha=alpha, attack=attack,
                           mal_frac=mf, seed=seed, clients=K)
                job += 1
                if job % args.workers != args.worker or key_of(row) in done:
                    continue
                res = run_federated(Xtr, ytr, Xte, yte, parts, len(classes), method=method,
                                    attack=attack, mal_frac=mf, rounds=args.rounds, seed=seed)
                row.update(res)
                row['classes'] = classes
                row['split'] = 'val' if args.val else 'test'
                with open(args.out, 'a') as f:
                    f.write(json.dumps(row) + '\n')
                done.add(key_of(row))
                print(f"{method:32s} a={alpha} {attack:10s} mal={mf:.1f} seed={seed} "
                      f"macroF1={res['macro_f1']:.4f} ASR={res.get('asr', float('nan')):.3f} ({res['time_s']:.0f}s)")


if __name__ == '__main__':
    main()
